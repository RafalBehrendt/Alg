public class NoSuchElementException  extends Exception{
        public NoSuchElementException (String message) {
            super(message);
        }
}
